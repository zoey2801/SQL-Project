Run create_db.sql to create database and tables (LPMCenter)
Run insert_db.sql to insert data
Run createTables.sql to create tables (Table1, Table2, Table3, Table4, Table5)
Run pro.py

Example how to call functions

Q_1(2)
Q_2(3)
Q_3(1500)
Q_4('General Medicine')
Q_5('Med A')
Q_6('2021-01-20')
Q_7('2021-04-01')
Q_8('General Medicine')
    
    

