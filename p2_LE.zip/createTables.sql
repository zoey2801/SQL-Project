#Table1
CREATE VIEW Table1 AS
(SELECT p.patientID, p.p_name, ph.Ph_name as primaryPhysician
FROM Patient as p, Physician as ph
WHERE p.primaryPhysID = ph.physicianID); #Table 1

#Table2
CREATE VIEW Table2 AS
(SELECT a.appID, a.patientID, n.N_name as NurseName, a.startDateTime, a.endDateTime, ph.Ph_name as PhysicianName
FROM Appointment as a, Nurse as n, Physician as ph
WHERE a.nurseID = n.nurseID AND
		a.physicianID = ph.physicianID);
  
#Table3  
CREATE VIEW Table3 AS
(SELECT *
FROM Undergoes as u JOIN `Procedure` as p
ON u.procedureID = p.procID);

#Table4
CREATE VIEW Table4 as
(SELECT ph.physicianID, d.deptID, d.D_name, ph.Ph_name, 
		ph.Ph_position, ph.ssn
FROM Department as d, Physician as ph, AffiliatedWith as a
WHERE a.physicianID = ph.physicianID
		AND a.departmentID = d.deptID);
      
#Table5
CREATE VIEW Table5 AS        
(SELECT p.*, a.appID ,a.physicianID
FROM Patient as p, Appointment as a
WHERE p.patientID = a.patientID);
