Run create_db.sql and insert_db.sql to get the database


Open project.py COMMAND LINE INTERFACE

>>> python project.py

A menu will be opened:
--------Las Palmas Medical Center Database-------
		...
	
2> Choose your option (Option from 1 - 4)--> ENTER

1. to view all table (option from 1- 12)
2. to insert data into tables (option from 1 -12)
3. Delete records (option from 1 - 12)
4. Close the connection

** option 12 is to exit out of the current window
