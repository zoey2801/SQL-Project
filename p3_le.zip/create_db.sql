
CREATE DATABASE LPMCenter;
# create tables:
#1

CREATE TABLE Physician
	(physicianID int AUTO_INCREMENT,
    Ph_name varchar(40) NOT NULL,
    Ph_position varchar(40),
    ssn int NOT NULL UNIQUE,
    Primary key (physicianID),
    CHECK (Ph_position in ('Intern','Surgeon','Senior','Chief of Medicine', 'Resident', 'Psychiatrist')));
#2
CREATE TABLE Department
	(deptID int AUTO_INCREMENT, #auto increment
    D_name varchar(40) NOT NULL,
    headID int,
    Primary key(deptID),
    Foreign key (headID) references Physician(physicianID) ON DELETE SET NULL, #delete phys this row turns null
    CHECK (D_name in('General Medicine','Surgery', 'Psychiatry')));

#3
CREATE TABLE AffiliatedWith
	(physicianID int,
    departmentID int,
    Primary key(physicianID, departmentID),
    Foreign key (physicianID) references Physician(physicianID) ON DELETE CASCADE,
    Foreign key (departmentID) references Department(deptID) ON DELETE CASCADE);
#4
CREATE TABLE `Procedure`
	(procID int AUTO_INCREMENT,
    p_name varchar(40) NOT NULL,
    cost real NOT NULL,
    Primary key (procID));
#5

CREATE TABLE Patient
	(patientID int AUTO_INCREMENT,
    ssn int NOT NULL unique,
    P_name varchar(40) NOT NULL,
    address varchar(100),
    dob date,
    phone varchar(16),
    insuranceNumber int,
    primaryPhysID int,
    primary key (patientID),
    foreign key (primaryPhysID) references Physician(physicianID) ON DELETE SET NULL);
#6
CREATE TABLE Nurse
		(nurseID int AUTO_INCREMENT,
        N_name varchar(40) NOT NULL,
        N_position varchar(40),
        ssn int NOT NULL UNIQUE,
        primary key(nurseID),
        CHECK (N_position IN ('Head Nurse','Nurse')));
#7
CREATE TABLE Medication
		(medID int AUTO_INCREMENT,
        m_name varchar(40) NOT NULL,
        primary key (medID));
#8
CREATE TABLE Prescribes
	(physicianID int,
    patientID int,
    medicationID int,
    prescribedDate date,
    dose varchar(40),
    primary key (physicianID, patientID,medicationID, prescribedDate),
    foreign key (physicianID) references Physician(physicianID) ,
    foreign key (patientID) references Patient(patientID) ,
    foreign key (medicationID) references Medication(medID) );
#9
CREATE TABLE Room
	(roomID int,
    roomType varchar(40),
    primary key (roomID),
    CHECK (roomType IN ('Single','Double')));
#10
CREATE TABLE Stay
	(stayID int AUTO_INCREMENT,
    patientID int,
    roomID int,
    startDate date,
    endDate date,
    primary key (stayID),
    foreign key (patientID) references Patient(patientID) ON DELETE CASCADE,
    foreign key (roomID) references Room(roomID) ON DELETE SET NULL);
#11
CREATE TABLE Undergoes
	(patientID int,
    procedureID int,
    stayID int,
    procDate date,
    physicianID int,
    nurseID int,
    primary key (patientID, stayID),
    foreign key (patientID) references Patient(patientID),
    foreign key (procedureID) references`Procedure`(procID) ON DELETE SET NULL,
    foreign key (stayID) references Stay(stayID) ,
    foreign key (physicianID) references Physician(physicianID) ON DELETE SET NULL,
    foreign key (nurseID) references Nurse(nurseID) ON DELETE SET NULL);
#12
CREATE TABLE Oncall
	(nurseID int,
    startDate date NOT NULL,
    endDate date,
    primary key (nurseID, startDate, endDate),
    foreign key (nurseID) references Nurse(nurseID) ON DELETE CASCADE);
#13
CREATE TABLE Appointment 
	(appID int AUTO_INCREMENT,
    patientID int,
    nurseID int,
    physicianID int,
    startDateTime datetime NOT NULL,
    endDateTime datetime NOT NULL,
    primary key (appID),
    foreign key (patientID) references Patient(patientID) ON DELETE CASCADE,
    foreign key (nurseID) references Nurse(nurseID) ON DELETE SET NULL,
    foreign key (physicianID) references Physician(physicianID) ON DELETE SET NULL);
    
    
    
 